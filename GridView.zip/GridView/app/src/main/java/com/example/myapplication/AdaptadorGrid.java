package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class AdaptadorGrid extends BaseAdapter {
    Context c;
    List<String> datos;
    int layout;

    public AdaptadorGrid(Context c, List<String> datos, int layout) {
        this.c = c;
        this.datos = datos;
        this.layout = layout;
    }

    @Override
    public int getCount() {
        return datos.size();
    }

    @Override
    public Object getItem(int i) {
        return datos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = LayoutInflater.from(c);
        View v = inflater.inflate(layout,null);
        TextView tv = v.findViewById(R.id.txt_titulo);
        tv.setText(datos.get(i));
        Button btn_1 = v.findViewById(R.id.btn_1);
        Button btn_2 = v.findViewById(R.id.btn_2);
        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(c, datos.get(i), Toast.LENGTH_SHORT).show();
            }
        });
        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datos.remove(i);
                notifyDataSetInvalidated();

            }
        });
        return v;
    }
}
